
#TraficoAEPViento.py

from __future__ import annotations
from typing import Dict, List, Optional, Set, Tuple

from TraficoAEP import TraficoAviones
from Aviones import Avion
from Constants import (
    MINUTE, SEPARACION_MINIMA, SEPARACION_PELIGRO, VEL_TURNAROUND,
    MAX_DIVERTED_DISTANCE, DAY_END, DAY_START
)

from Helpers import velocidad_por_distancia, mins_a_aep, knots_to_nm_per_min



class TraficoAEPViento(TraficoAviones):

    # Suponiendo que vaya a 150 nudos en el final, 150 nudos = 150 millas náuticas/hora → 150÷60= 2,5 millas náuticas por minuto
    def __init__(self, seed: int = 42, p_goaround: float = 0.10, final_threshold_nm: float = 2.5) -> None:
        super().__init__(seed=seed)
        self.p_goaround = float(p_goaround)
        self.final_threshold_nm = float(final_threshold_nm)
        # estado adicional
        self.interrupted: List[int] = []
        self.recien_interrupted: Set[int] = set()
        self.current_min: int = DAY_START


    #------------------ helpers adicionales --------------------------

    def mover_a_interrupted(self, aid: int) -> None:
        if aid in self.activos:
            self.activos.remove(aid)
        if aid not in self.interrupted:
            self.interrupted.append(aid)
            self.recien_interrupted.add(aid)
        self.planes[aid].leader_id = None


    def mover_interrupted_a_activos(self, aid: int) -> None:
        if aid in self.interrupted:
            self.interrupted.remove(aid)
        if aid not in self.activos:
            self.activos.append(aid)

    def mover_a_inactivos(self, aid: int) -> None:
        ''' mueve un avión del carril activo o turnaround o interrupted a inactivos (landed o diverted) '''
        if aid in self.activos:
            self.activos.remove(aid)
        if aid in self.turnaround:
            self.turnaround.remove(aid)
        if aid in self.interrupted:
            self.interrupted.remove(aid)
        if aid not in self.inactivos:
            self.inactivos.append(aid)
        self.planes[aid].leader_id = None


    # ---------- control ----------

    """ def control_paso(self) -> None:
        # snapshot de velocidades y distancias antes de decidir
        speed_prev = {aid: self.planes[aid].velocidad_kts for aid in self.activos}
        dist_prev = {aid: self.planes[aid].distancia_nm for aid in self.activos}
        self.ordenar_activos(current_speeds=speed_prev)

        self.recien_turnaround.clear()
        self.recien_interrupted.clear()

        for aid in list(self.activos):
            av = self.planes[aid]
            vmin, vmax = velocidad_por_distancia(dist_prev[aid])

            # --- go-around por viento: sólo si aterrizaba en este paso ---
            avance_nm = knots_to_nm_per_min(speed_prev[aid]) * MINUTE
            aterriza_este_paso = (dist_prev[aid] - avance_nm) <= 0.0

            if aterriza_este_paso:
                # tirar la moneda una única vez por avión
                if not getattr(av, "goaround_checked", False):
                    av.goaround_checked = True
                    if self.rng.random() < self.p_goaround:
                        av.estado = "interrupted"
                        av.velocidad_kts = VEL_TURNAROUND
                        self.mover_a_interrupted(aid)
                        continue 


            # --- control normal (separación con líder) ---
            leader_id = av.leader_id
            if leader_id is None:
                av.velocidad_kts = vmax
                continue

            # my_eta = mins_a_aep(dist_prev[aid], vmax)
            my_eta = mins_a_aep(dist_prev[aid], speed_prev[aid])
            lead_eta = mins_a_aep(dist_prev[leader_id], speed_prev[leader_id])
            gap = my_eta - lead_eta

            if gap < SEPARACION_PELIGRO:
                nueva = min(vmax, speed_prev[leader_id] - 20.0)
                if nueva < vmin:
                    av.estado = "turnaround"
                    av.velocidad_kts = VEL_TURNAROUND
                    self.mover_a_turnaround(aid)
                    self.recien_turnaround.add(aid)
                else:
                    av.velocidad_kts = max(vmin, nueva)
            else:
                av.velocidad_kts = vmax

        # reingreso: probar huecos para turnaround + interrupted
        activos_order = list(self.activos)
        self.intentar_reingreso_con_interrupted(activos_order) """
    def control_paso(self) -> None:
        """
        - Go-around por viento: sólo si iba a aterrizar ESTE minuto según el snapshot
        (y sólo una vez por avión via flag goaround_checked).
        - Separación: líder definido por DISTANCIA (más cerca a AEP). Barrido Gauss-Seidel:
        el seguidor usa la velocidad ya ajustada del líder y se retrasa para cumplir
        líder + SEPARACION_MINIMA. Si no alcanza con vmin -> turnaround del seguidor.
        - Luego intentamos reingresos (turnaround + interrupted) actualizando huecos
        tras cada inserción.
        """
        # Snapshot de inicio del minuto (distancias/velocidades congeladas para decidir)
        speed_prev = {aid: self.planes[aid].velocidad_kts for aid in self.activos}
        dist_prev  = {aid: self.planes[aid].distancia_nm  for aid in self.activos}

        # Orden por DISTANCIA para definir líderes físicos (menor distancia primero)
        order_dist = sorted(self.activos, key=lambda x: dist_prev[x])
        for i, aid in enumerate(order_dist):
            self.planes[aid].leader_id = order_dist[i-1] if i > 0 else None

        self.recien_turnaround.clear()
        self.recien_interrupted.clear()

        # 1) Go-around por viento (antes de tocar separaciones)
        for aid in list(order_dist):
            av = self.planes[aid]
            # ¿aterrizaba ESTE minuto con la velocidad del snapshot?
            avance_nm = knots_to_nm_per_min(speed_prev[aid]) * MINUTE
            aterriza_este_paso = (dist_prev[aid] - avance_nm) <= 0.0
            if aterriza_este_paso and not getattr(av, "goaround_checked", False):
                av.goaround_checked = True
                if self.rng.random() < self.p_goaround:
                    av.estado = "interrupted"
                    av.velocidad_kts = VEL_TURNAROUND
                    self.mover_a_interrupted(aid)

        # Si quitamos activos por go-around, refrescamos snapshot y orden por distancia
        speed_prev = {aid: self.planes[aid].velocidad_kts for aid in self.activos}
        dist_prev  = {aid: self.planes[aid].distancia_nm  for aid in self.activos}
        order_dist = sorted(self.activos, key=lambda x: dist_prev[x])
        for i, aid in enumerate(order_dist):
            self.planes[aid].leader_id = order_dist[i-1] if i > 0 else None

        # 2) Separaciones (Gauss-Seidel) con líder por DISTANCIA
        EPS = 1e-6          # un poco más holgado que 1e-9 para evitar micro-oscilaciones
        MAX_LOOPS = 50      # guardrail para no colgarse jamás
        loops = 0

        while True:
            loops += 1
            if not order_dist or loops > MAX_LOOPS:
                break

            v_curr = {aid: speed_prev.get(aid, self.planes[aid].velocidad_kts) for aid in order_dist}
            changed_turn = False
            changed_speed = False

            for i, aid in enumerate(order_dist):
                av = self.planes[aid]
                d  = dist_prev[aid]
                vmin, vmax = velocidad_por_distancia(d)

                if i == 0:
                    if abs(v_curr.get(aid, 0.0) - vmax) > EPS:
                        v_curr[aid] = vmax
                        av.velocidad_kts = vmax
                        changed_speed = True
                    continue

                leader_id = order_dist[i-1]
                v_lead  = max(EPS, v_curr.get(leader_id, speed_prev.get(leader_id, 0.0)))
                lead_eta = mins_a_aep(dist_prev[leader_id], v_lead)

                my_v   = max(EPS, v_curr.get(aid, speed_prev.get(aid, 0.0)))
                my_eta = mins_a_aep(d, my_v)

                min_eta = lead_eta + SEPARACION_MINIMA
                if my_eta + 1e-12 < min_eta:
                    needed_v = (d / min_eta) * 60.0
                    if needed_v < vmin - 1e-9:
                        av.estado = "turnaround"
                        av.velocidad_kts = VEL_TURNAROUND
                        self.mover_a_turnaround(aid)
                        self.recien_turnaround.add(aid)
                        changed_turn = True
                        break
                    target_v = min(max(needed_v, vmin), vmax)
                else:
                    target_v = vmax

                if abs(target_v - v_curr.get(aid, 0.0)) > EPS:
                    v_curr[aid] = target_v
                    av.velocidad_kts = target_v
                    changed_speed = True

            if not changed_turn and not changed_speed:
                break

            if changed_turn:
                # refresco total
                speed_prev = {aid: self.planes[aid].velocidad_kts for aid in self.activos}
                dist_prev  = {aid: self.planes[aid].distancia_nm  for aid in self.activos}
                order_dist = sorted(self.activos, key=lambda x: dist_prev[x])
                for i, aid in enumerate(order_dist):
                    self.planes[aid].leader_id = order_dist[i-1] if i > 0 else None
            else:
                # sólo cambio de velocidad: propago nueva “foto”
                speed_prev = {aid: v_curr.get(aid, self.planes[aid].velocidad_kts) for aid in order_dist}

        # reingresos como ya tenés:
        activos_order = list(self.activos)
        self.intentar_reingreso_con_interrupted(activos_order)






        """ 

    def intentar_reingreso_con_interrupted(self, activos_order: List[int]) -> None:
        
        Igual que intentar_reingreso(base), pero permite reinsertar también
        los 'interrupted' (go-around) con la misma regla de huecos.
        Extra: por seguridad, no reinsertar interrupted si d <= 5 nm.
        
        if not activos_order:
            # si no hay activos, vuelven directo a approach a vmax
            for aid in list(self.turnaround) + list(self.interrupted):
                av = self.planes[aid]
                vmin, vmax = av.limites_velocidad()
                av.velocidad_kts = vmax
                av.estado = "approach"
                if aid in self.turnaround:
                    self.mover_a_activos(aid)
                elif aid in self.interrupted:
                    self.mover_interrupted_a_activos(aid)
            return

        # (id, ETA) ordenado por llegada
        activos_eta = [(aid, self.planes[aid].tiempo_a_aep()) for aid in activos_order]
        activos_eta.sort(key=lambda x: x[1])

        reintegrables = list(self.turnaround) + list(self.interrupted)
        for aid in reintegrables:
            av = self.planes[aid]
            d = av.distancia_nm
            vmin, vmax = av.limites_velocidad()
            t_fast = mins_a_aep(d, vmax)
            t_slow = mins_a_aep(d, vmin)

            # restricción para interrupted: no reinsertar si ya está pegado a AEP
            if aid in self.interrupted and d <= 5.0:
                continue

            reinsertado = False

            # entre pares
            for (a1, t1), (a2, t2) in zip(activos_eta, activos_eta[1:]):
                t_low = t1 + SEPARACION_MINIMA
                t_high = t2 - SEPARACION_MINIMA
                if t_high < t_low:
                    continue
                a = max(t_low, t_fast)
                b = min(t_high, t_slow)
                if a <= b:
                    t_target = 0.5 * (a + b)
                    v_target = (d / t_target) * 60.0
                    v_target = min(max(v_target, vmin), vmax)
                    my_mins_to_aep = mins_a_aep(d, v_target)
                    if t_low <= my_mins_to_aep <= t_high:
                        av.velocidad_kts = v_target
                        av.estado = "approach"
                        if aid in self.turnaround:
                            self.mover_a_activos(aid)
                        else:
                            self.mover_interrupted_a_activos(aid)
                        reinsertado = True
                        break
            if reinsertado:
                continue

            # antes del primero
            first_t = activos_eta[0][1]
            t_high = first_t - SEPARACION_MINIMA
            a = t_fast
            b = min(t_high, t_slow)
            if a <= b:
                t_target = 0.5 * (a + b)
                v_target = (d / t_target) * 60.0
                v_target = min(max(v_target, vmin), vmax)
                my_mins_to_aep = mins_a_aep(d, v_target)
                if my_mins_to_aep <= t_high:
                    av.velocidad_kts = v_target
                    av.estado = "approach"
                    if aid in self.turnaround:
                        self.mover_a_activos(aid)
                    else:
                        self.mover_interrupted_a_activos(aid)
                    continue

            # después del último
            last_t = activos_eta[-1][1]
            t_low = last_t + SEPARACION_MINIMA
            a = max(t_low, t_fast)
            b = t_slow
            if a <= b:
                t_target = 0.5 * (a + b)
                v_target = (d / t_target) * 60.0
                v_target = min(max(v_target, vmin), vmax)
                my_mins_to_aep = mins_a_aep(d, v_target)
                if my_mins_to_aep >= t_low:
                    av.velocidad_kts = v_target
                    av.estado = "approach"
                    if aid in self.turnaround:
                        self.mover_a_activos(aid)
                    else:
                        self.mover_interrupted_a_activos(aid)
                    continue
 """

    def intentar_reingreso_con_interrupted(self, activos_order: List[int]) -> None:
        """
        Inserta TODOS los turnaround + interrupted que quepan en huecos válidos.
        Tras cada inserción, actualiza la cola de ETAs para no meter dos en el mismo hueco.
        Regla extra: por seguridad, no reinsertar 'interrupted' si d <= 5 nm.
        """
        # Si no hay activos, regresan todos directo a approach @ vmax
        if not activos_order:
            for aid in list(self.turnaround) + list(self.interrupted):
                av = self.planes[aid]
                vmin, vmax = av.limites_velocidad()
                av.velocidad_kts = vmax
                av.estado = "approach"
                if aid in self.turnaround:
                    self.mover_a_activos(aid)
                else:
                    self.mover_interrupted_a_activos(aid)
            return

        # Construyo (id, ETA) ordenado por llegada
        activos_eta = [(aid, self.planes[aid].tiempo_a_aep()) for aid in activos_order]
        activos_eta.sort(key=lambda x: x[1])

        EPS = 1e-9
        while True:
            inserted_any = False
            candidatos = list(self.turnaround) + list(self.interrupted)

            for aid in candidatos:
                if aid not in self.turnaround and aid not in self.interrupted:
                    continue

                av = self.planes[aid]
                d = av.distancia_nm
                vmin, vmax = av.limites_velocidad()
                t_fast = mins_a_aep(d, vmax)
                t_slow = mins_a_aep(d, vmin)

                if aid in self.interrupted and d <= 5.0:
                    continue

                placed = False

                # 1) Entre pares
                for (a1, t1), (a2, t2) in zip(activos_eta, activos_eta[1:]):
                    t_low  = t1 + SEPARACION_MINIMA
                    t_high = t2 - SEPARACION_MINIMA
                    if t_high + EPS < t_low:
                        continue
                    a = max(t_low,  t_fast)
                    b = min(t_high, t_slow)
                    if a - EPS <= b:
                        t_target = 0.5 * (a + b)
                        v_target = (d / t_target) * 60.0
                        v_target = min(max(v_target, vmin), vmax)
                        my_t = mins_a_aep(d, v_target)
                        if t_low - EPS <= my_t <= t_high + EPS:
                            av.velocidad_kts = v_target
                            av.estado = "approach"
                            if aid in self.turnaround:
                                self.mover_a_activos(aid)
                            else:
                                self.mover_interrupted_a_activos(aid)
                            activos_eta.append((aid, my_t))
                            activos_eta.sort(key=lambda x: x[1])
                            inserted_any = True
                            placed = True
                            break
                if placed:
                    continue

                # 2) Antes del primero
                first_t = activos_eta[0][1]
                t_high = first_t - SEPARACION_MINIMA
                a = t_fast
                b = min(t_high, t_slow)
                if a - EPS <= b:
                    t_target = 0.5 * (a + b)
                    v_target = (d / t_target) * 60.0
                    v_target = min(max(v_target, vmin), vmax)
                    my_t = mins_a_aep(d, v_target)
                    if my_t <= t_high + EPS:
                        av.velocidad_kts = v_target
                        av.estado = "approach"
                        if aid in self.turnaround:
                            self.mover_a_activos(aid)
                        else:
                            self.mover_interrupted_a_activos(aid)
                        activos_eta.append((aid, my_t))
                        activos_eta.sort(key=lambda x: x[1])
                        inserted_any = True
                        continue

                # 3) Después del último
                last_t = activos_eta[-1][1]
                t_low = last_t + SEPARACION_MINIMA
                a = max(t_low, t_fast)
                b = t_slow
                if a - EPS <= b:
                    t_target = 0.5 * (a + b)
                    v_target = (d / t_target) * 60.0
                    v_target = min(max(v_target, vmin), vmax)
                    my_t = mins_a_aep(d, v_target)
                    if my_t + EPS >= t_low:
                        av.velocidad_kts = v_target
                        av.estado = "approach"
                        if aid in self.turnaround:
                            self.mover_a_activos(aid)
                        else:
                            self.mover_interrupted_a_activos(aid)
                        activos_eta.append((aid, my_t))
                        activos_eta.sort(key=lambda x: x[1])
                        inserted_any = True
                        continue

            if not inserted_any:
                break




    # ---------- movimiento ----------
    def mover_paso(self) -> None:
        # approach (idéntico a base, setea aterrizaje_min)
        for aid in list(self.activos):
            av = self.planes[aid]
            avance_nm = knots_to_nm_per_min(av.velocidad_kts) * MINUTE
            d_prev = av.distancia_nm
            new_dist = max(0.0, d_prev - avance_nm)
            if new_dist <= 0.0:
                s = (d_prev/avance_nm) if avance_nm > 0 else 1.0
                av.aterrizaje_min = int(self.current_min)
                t_cont = float(self.current_min) + float(s)
                setattr(self.planes[aid], "aterrizaje_min_cont", float(t_cont))
                setattr(self.planes[aid], "aterrizaje_min_continuo", float(t_cont))
                av.distancia_nm = 0.0
                av.velocidad_kts = 0.0
                av.estado = "landed"
                self.mover_a_inactivos(aid)
                continue

            self.planes[aid].distancia_nm = new_dist

        # turnaround (igual a base)
        for aid in list(self.turnaround):
            if aid in self.recien_turnaround:
                continue
            av = self.planes[aid]
            av.distancia_nm += knots_to_nm_per_min(VEL_TURNAROUND) * MINUTE
            if av.distancia_nm >= MAX_DIVERTED_DISTANCE:
                av.estado = "diverted"
                self.mover_a_inactivos(aid)

        # interrupted (nuevo: se aleja también a VEL_TURNAROUND)
        for aid in list(self.interrupted):
            if aid in self.recien_interrupted:
                continue
            av = self.planes[aid]
            av.distancia_nm += knots_to_nm_per_min(VEL_TURNAROUND) * MINUTE
            if av.distancia_nm >= MAX_DIVERTED_DISTANCE:
                av.estado = "diverted"
                self.mover_a_inactivos(aid)

        self.ordenar_activos()


    # ---------- step ----------
    def step(self, minuto: int, aparicion: bool) -> None:
        self.current_min = minuto
        if aparicion:
            self.aparicion(minuto)
        self.control_paso()
        self.mover_paso()

    def aviones_landed(self) -> List[Avion]:
        return [av for av in self.planes.values() if av.aterrizaje_min is not None]
    # filtra solo los aviones que realmente aterrizaron 